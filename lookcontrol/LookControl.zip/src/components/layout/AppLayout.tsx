import { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Package, ShoppingCart, Truck,
  TrendingUp, Scissors, Users, User, LogOut, Menu, X, ChevronRight
} from 'lucide-react';
import { useAuthStore } from '../../store/authStore';

const NAV_ITEMS = [
  { to: '/dashboard',   label: 'Dashboard',   icon: LayoutDashboard, roles: ['admin', 'user', 'empleado'] },
  { to: '/productos',   label: 'Productos',    icon: Package,         roles: ['admin', 'user', 'empleado'] },
  { to: '/stock',       label: 'Stock',        icon: TrendingUp,      roles: ['admin', 'user', 'empleado'] },
  { to: '/compras',     label: 'Compras',      icon: ShoppingCart,    roles: ['admin', 'user', 'empleado'] },
  { to: '/proveedores', label: 'Proveedores',  icon: Truck,           roles: ['admin', 'user', 'empleado'] },
  { to: '/servicios',   label: 'Servicios',    icon: Scissors,        roles: ['admin', 'user', 'empleado'] },
  { to: '/admin',       label: 'Administrar',  icon: Users,           roles: ['admin'] },
];

export default function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { perfil, logout } = useAuthStore();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const visibleItems = NAV_ITEMS.filter(item =>
    perfil?.rol && item.roles.includes(perfil.rol)
  );

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="px-6 py-5 border-b border-(--border-base)">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-(--brand-primary) flex items-center justify-center">
            <Scissors size={16} className="text-black" />
          </div>
          <span className="font-bold text-lg text-(--text-primary) tracking-tight">LookControl</span>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {visibleItems.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            onClick={() => setSidebarOpen(false)}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                isActive
                  ? 'nav-active'
                  : 'text-(--text-secondary) hover:text-(--text-primary) hover:bg-(--bg-elevated)'
              }`
            }
          >
            <Icon size={18} />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>

      {/* User footer */}
      <div className="px-3 py-4 border-t border-(--border-base) space-y-1">
        <NavLink
          to="/profile"
          onClick={() => setSidebarOpen(false)}
          className={({ isActive }) =>
            `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
              isActive
                ? 'nav-active'
                : 'text-(--text-secondary) hover:text-(--text-primary) hover:bg-(--bg-elevated)'
            }`
          }
        >
          {perfil?.avatar_url
            ? <img src={perfil.avatar_url} alt="" className="w-6 h-6 rounded-full object-cover" />
            : <User size={18} />
          }
          <div className="flex-1 min-w-0">
            <p className="truncate text-xs font-semibold text-(--text-primary)">
              {perfil?.nombre_completo ?? perfil?.email}
            </p>
            <p className="truncate text-[10px] text-(--text-muted) capitalize">{perfil?.rol}</p>
          </div>
          <ChevronRight size={14} />
        </NavLink>
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-(--text-secondary) hover:text-(--brand-danger) hover:bg-(--bg-elevated) transition-colors"
        >
          <LogOut size={18} />
          Cerrar sesión
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-(--bg-base) overflow-hidden">
      {/* Sidebar desktop */}
      <aside className="hidden md:flex w-60 shrink-0 flex-col bg-(--bg-surface) border-r border-(--border-base)">
        <SidebarContent />
      </aside>

      {/* Sidebar mobile overlay */}
      {sidebarOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex">
          <div className="fixed inset-0 bg-black/60" onClick={() => setSidebarOpen(false)} />
          <aside className="relative w-64 bg-(--bg-surface) border-r border-(--border-base) flex flex-col z-10">
            <button
              className="absolute top-4 right-4 text-(--text-secondary)"
              onClick={() => setSidebarOpen(false)}
            >
              <X size={20} />
            </button>
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Topbar mobile */}
        <header className="md:hidden flex items-center gap-3 px-4 py-3 border-b border-(--border-base) bg-(--bg-surface)">
          <button onClick={() => setSidebarOpen(true)} className="text-(--text-secondary)">
            <Menu size={22} />
          </button>
          <span className="font-bold text-(--text-primary)">LookControl</span>
        </header>

        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

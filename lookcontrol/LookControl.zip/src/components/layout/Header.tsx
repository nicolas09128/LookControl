import { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Scissors, Menu, X } from 'lucide-react';

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  const isLandingPage = location.pathname === '/';

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => setMobileMenuOpen(false), [location]);

  const closeMobileMenu = () => setMobileMenuOpen(false);

  const getHeaderClasses = () => {
    const base = 'site-header transition-all duration-300';
    if (isLandingPage && !scrolled) {
      return `${base} header-transparent`;
    }
    return `${base} header-solid`;
  };

  const navLinkClass = ({ isActive }: { isActive: boolean }) =>
    `header-nav-link${isActive ? ' active' : ''}`;

  return (
    <>
      <header className={getHeaderClasses()}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between header-inner">

          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group shrink-0 no-underline">
            <div className="w-9 h-9 rounded-xl bg-linear-to-br from-[#38BDF8] to-[#7DD3FC] flex items-center justify-center shadow-md group-hover:shadow-lg group-hover:scale-105 transition-all duration-300">
              <Scissors size={18} className="text-[#0F172A]" />
            </div>
            <span className="hidden sm:block font-bold text-lg tracking-tight leading-none text-white">
              LookControl
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="header-nav hidden md:flex">
            <NavLink to="/nosotros" className={navLinkClass}>Servicios</NavLink>
            <NavLink to="/precios"  className={navLinkClass}>Precios</NavLink>
          </nav>

          {/* Desktop Buttons */}
          <div className="header-actions hidden md:flex">
            <NavLink to="/login" className="header-btn-ghost no-underline">
              Iniciar Sesión
            </NavLink>
            <NavLink to="/register" className="header-btn-primary no-underline">
              Empezar gratis
            </NavLink>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg transition-all duration-200 bg-gray-800/80 text-gray-300 hover:bg-gray-700 hover:text-white"
            aria-label="Menú"
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </header>

      {/* Mobile Overlay */}
      <div
        className={`md:hidden fixed inset-0 bg-black/60 backdrop-blur-sm transition-all duration-300 ${
          mobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible pointer-events-none'
        }`}
        style={{ zIndex: 900 }}
        onClick={closeMobileMenu}
      />

      {/* Mobile Menu Panel */}
      <div
        className={`md:hidden fixed left-4 right-4 bg-[#1E293B] border border-[#334155] rounded-2xl shadow-2xl transition-all duration-300 ${
          mobileMenuOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4 pointer-events-none'
        }`}
        style={{ top: 'calc(var(--header-height) + 8px)', zIndex: 950 }}
      >
        <nav className="flex flex-col p-4 gap-1">
          <NavLink
            to="/nosotros"
            onClick={closeMobileMenu}
            className={({ isActive }) =>
              `px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 no-underline ${
                isActive ? 'bg-[#38BDF8]/10 text-[#38BDF8]' : 'text-gray-300 hover:bg-gray-800 hover:text-white'
              }`
            }
          >
            Servicios
          </NavLink>
          <NavLink
            to="/precios"
            onClick={closeMobileMenu}
            className={({ isActive }) =>
              `px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 no-underline ${
                isActive ? 'bg-[#38BDF8]/10 text-[#38BDF8]' : 'text-gray-300 hover:bg-gray-800 hover:text-white'
              }`
            }
          >
            Precios
          </NavLink>

          <div className="h-px bg-[#334155] my-2" />

          <NavLink
            to="/login"
            onClick={closeMobileMenu}
            className="px-4 py-3 text-center text-gray-300 font-medium rounded-xl hover:bg-gray-800 hover:text-white transition-all duration-200 no-underline"
          >
            Iniciar Sesión
          </NavLink>
          <NavLink
            to="/register"
            onClick={closeMobileMenu}
            className="px-4 py-3 text-center font-semibold bg-linear-to-r from-[#38BDF8] to-[#7DD3FC] text-[#0F172A] rounded-xl shadow-md mt-2 transition-all duration-200 hover:shadow-lg active:scale-95 no-underline"
          >
            Empezar gratis
          </NavLink>
        </nav>
      </div>
    </>
  );
}
